package fr.groupe4.tondeuseJAVA;

import fr.groupe4.tondeuseJAVA.map.Map;

public class Main {

    public static void main(String[] args) {


        //Chemin du fichier de conf : ./config/src/config.txt
        Map worldMap = new Map();

    }
    /*public void verifI(int l, int c){
        if (map[l][c] == 'I'){
            System.out.print("esrser");
        }else{
            System.out.print("Erreur, cet emplacement n'est pas I.\n");
        }
    }*/
}