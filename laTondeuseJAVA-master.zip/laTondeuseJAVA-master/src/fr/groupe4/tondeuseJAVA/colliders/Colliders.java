package fr.groupe4.tondeuseJAVA.colliders;


public abstract class Colliders implements Inventaire {

    protected int posX;
    protected int posY;


    public Colliders() {

    }

    public abstract void placer(int posY, int posX);

    public abstract void Verif();

    public int getPosY() {

        return this.posY;
    }

    public int getPosX() {

        return this.posX;
    }
}