package fr.groupe4.tondeuseJAVA.colliders;

public class Items extends Colliders {

    @Override
    public void placer(int posY, int posX) {
        this.posX = posX;
        this.posY = posY;
        System.out.println("x " + posX + " y " + posY);
    }

    @Override
    public void Verif() {

    }

}