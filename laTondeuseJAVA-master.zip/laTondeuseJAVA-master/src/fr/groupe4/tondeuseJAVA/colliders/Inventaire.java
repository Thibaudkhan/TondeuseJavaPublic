package fr.groupe4.tondeuseJAVA.colliders;

import java.util.ArrayList;
import java.util.List;

public interface Inventaire {

    List<String> liste = new ArrayList<String>();

    default void enlever() {
        liste.remove("item");
    }

    default void ajouter() {
        liste.add("item");

    }

}

