package fr.groupe4.tondeuseJAVA.colliders;

import fr.groupe4.tondeuseJAVA.map.Map;

public class Tondeuse extends Colliders {

    protected String Nord = "N";
    protected String Sud = "S";
    protected String Est = "E";
    protected String Ouest = "O";
    protected String orientation;

    public Tondeuse() {
        System.out.println(orientation);
    }

    @Override
    public void placer(int posY, int posX) {
        this.posX = posX;
        this.posY = posY;
        System.out.println("x tondeuse" + posX + " y tondeuse" + posY);
    }

    @Override
    public void Verif() {
        if (posX != 1) {
            posX = 1;
        }

        if (posY != 1) {
            posY = 1;
        }
    }

    public void oriente(String direction) {
        if (direction.equals("D")) {
            if (orientation.equals("N")) {
                orientation = Est;
            } else if (orientation.equals("E")) {
                orientation = Sud;
            } else if (orientation.equals("S")) {
                orientation = Ouest;
            } else if (orientation.equals("O")) {
                orientation = Nord;
            }
            System.out.println("LA TONDEUSE TOURNE VERS LA DROITE");
        } else if (direction.equals("G")) {
            if (orientation.equals("N")) {
                orientation = Ouest;
            } else if (orientation.equals("O")) {
                orientation = Sud;
            } else if (orientation.equals("S")) {
                orientation = Est;
            } else if (orientation.equals("E")) {
                orientation = Nord;
            }
            System.out.println("LA TONDEUSE TOURNE VERS LA GAUCHE");
        }
        System.out.println("L'orientation est : " + orientation);

    }

    public void reculer() {
        if (orientation.equals("N")) {
            posY += 1;
        } else if (orientation.equals("S")) {
            posY -= 1;
        } else if (orientation.equals("O")) {
            posX += 1;
        } else if (orientation.equals("E")) {
            posX -= 1;
        }
        System.out.println("ON RECULE");
    }

    public void deplacer() {
        switch (orientation) {
            case "N":
                if (posY == 1) {
                    System.out.println("NORD IMPOSSIBLE DE PASSER");
                    System.out.println("la tondeuse ne peux pas quitter la map");
                } else {
                    posY -= 1;
                    System.out.println(posX + " " + posY);
                }
                break;
            case "S":
                // TODO changer le 20 en fonction du fichier de test
                if (posY == Integer.parseInt(Map.getLigne()) - 1) {
                    System.out.println("SUD IMPOSSIBLE DE PASSER");
                    System.out.println("la tondeuse ne peux pas quitter la map");
                } else {
                    posY += 1;
                    System.out.println(posX + " " + posY);
                }
                break;
            case "O":
                if (posX == 1) {
                    System.out.println("OUEST IMPOSSIBLE DE PASSER");
                    System.out.println("la tondeuse ne peux pas quitter la map");
                } else {
                    posX -= 1;
                    System.out.println(posX + " " + posY);
                }
                break;
            case "E":
                // TODO changer le 12 en fonction du fichier de test
                if (posX == Integer.parseInt(Map.getColonne()) - 1) {
                    System.out.println("EST IMPOSSIBLE DE PASSER");
                    System.out.println("la tondeuse ne peux pas quitter la map");
                } else {
                    posX += 1;
                    System.out.println(posX + " " + posY);
                }
                break;
        }
        System.out.println("LA TONDEUSE AVANCE");
    }

    public String getOrientation() {
        return this.orientation;
    }

    public void setOrientation(String orient) {
        this.orientation = orient;
        System.out.println(orientation + " " + orient);
    }
}
