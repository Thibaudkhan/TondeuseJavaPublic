package fr.groupe4.tondeuseJAVA.colliders;

public class Obstacle extends Colliders {

    @Override
    public void placer(int posY, int posX) {
        this.posY = posY;
        this.posX = posX;
        System.out.println("x " + posX + " y " + posY);
    }

    @Override
    public void Verif() {

    }
}