package fr.groupe4.tondeuseJAVA.colliders;

public interface Verification {

    public void verifI(int l, int c);
}