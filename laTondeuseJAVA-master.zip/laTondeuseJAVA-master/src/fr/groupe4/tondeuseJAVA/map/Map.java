package fr.groupe4.tondeuseJAVA.map;

import fr.groupe4.tondeuseJAVA.LectureFichier;
import fr.groupe4.tondeuseJAVA.colliders.Inventaire;
import fr.groupe4.tondeuseJAVA.colliders.Items;
import fr.groupe4.tondeuseJAVA.colliders.Obstacle;
import fr.groupe4.tondeuseJAVA.colliders.Tondeuse;

public class Map implements Inventaire {

    private int nbLig;
    private int nbCol;

    private String[][] map;
    private Tondeuse tondeuse;
    private Obstacle obstacle;
    private Items item;
    // private int cptitem = 0;

    private static String ligne;
    private static String colonne;
    private boolean suppresionItem = false;
    private boolean suppresionObstacle = false;


    public Map() {

        LectureFichier lectureFichier = new LectureFichier();
        ligne = lectureFichier.getListe(String.valueOf(0));
        colonne = lectureFichier.getListe(String.valueOf(1));

        this.nbLig = Integer.parseInt(ligne);
        this.nbCol = Integer.parseInt(colonne);

        map = new String[nbLig][nbCol];

        for (int i = 1; i < nbLig; i++) {

            for (int j = 1; j < nbCol; j++) {

                map[i][j] = " ";
            }
        }
        afficher();
        String colliderposX;
        String colliderposY;
        int colliderPosX2;
        int colliderPosY2;

        try {

            for (int i = 0; i < lectureFichier.getListeLength(); i++) {
                System.out.println("LISTE LENGTH : " + lectureFichier.getListeLength());
                System.out.println("Valeur fichier : " + lectureFichier.getListe(String.valueOf(i)));
                try {
                    //Coordonnées et créations Obstacle
                    if (lectureFichier.getListe(String.valueOf(i)).equals("O")) {
                        colliderposX = lectureFichier.getListe(String.valueOf(i + 1));
                        colliderposY = lectureFichier.getListe(String.valueOf(i + 2));
                        colliderPosX2 = Integer.parseInt(colliderposX);
                        colliderPosY2 = Integer.parseInt(colliderposY);
                        System.out.println("Spawn Obstacle :"+colliderposX + " " + colliderposY + " " + colliderPosX2 + " " + colliderPosY2);
                        spawnCollider("O");
                        obstacle.placer(colliderPosY2, colliderPosX2);
                        placer(obstacle.getPosX(), obstacle.getPosY(), "O");
                        afficher();
                    }

                    //Coordonnées et créations Items
                    else if (lectureFichier.getListe(String.valueOf(i)).equals("I")) {
                        colliderposX = lectureFichier.getListe(String.valueOf(i + 1));
                        colliderposY = lectureFichier.getListe(String.valueOf(i + 2));
                        colliderPosX2 = Integer.parseInt(colliderposX);
                        colliderPosY2 = Integer.parseInt(colliderposY);
                        spawnCollider("I");
                        item.placer(colliderPosY2, colliderPosX2);
                        placer(item.getPosX(), item.getPosY(), "I");
                        afficher();
                        System.out.println("Items coords " + colliderPosX2 + " " + colliderPosY2);
                    }

                    //Coordonnées et créations Tondeuse
                    else if (lectureFichier.getListe(String.valueOf(i)).equals("T")) {
                        colliderposX = lectureFichier.getListe(String.valueOf(i + 1));
                        colliderposY = lectureFichier.getListe(String.valueOf(i + 2));
                        String orientationTondeuse = lectureFichier.getListe(String.valueOf(i + 3));
                        colliderPosX2 = Integer.parseInt(colliderposX);
                        colliderPosY2 = Integer.parseInt(colliderposY);
                        spawnCollider("T");
                        tondeuse.setOrientation(orientationTondeuse);
                        tondeuse.Verif();
                        tondeuse.placer(colliderPosY2, colliderPosX2);
                        placer(tondeuse.getPosX(), tondeuse.getPosY(), "T");
                        afficher();
                    }

                    //Mouvement de la Tondeuse
                    else if (lectureFichier.getListe(String.valueOf(i)).equals("M")) {

                        String listeMouvement = lectureFichier.getListe(String.valueOf(i + 1));
                        System.out.println("listeMouvement.length"+listeMouvement.length());
                        String[] caracMvt = listeMouvement.split("");
                        for (int j = 0; j < caracMvt.length; j++) {
                            switch (caracMvt[j]) {
                                case "G":
                                    tondeuse.oriente("G");
                                    break;
                                case "D":
                                    tondeuse.oriente("D");
                                    break;
                                case "A":
                                    tondeuse.deplacer();
                                    placer(tondeuse.getPosY(), tondeuse.getPosX(), "T");
                                    afficher();
                                    break;
                                default:
                                    System.out.println("L'entrée n'est pas valide");
                                    break;

                            }
                            if (obstacle != null) {
                                System.out.println("obstacle coords " + obstacle.getPosX() + " " + obstacle.getPosY());
                                if (tondeuse.getPosX() == obstacle.getPosY() && tondeuse.getPosY() == obstacle.getPosX()) {
                                    System.out.println("les obstacle pas les items ");
                                    enlever();
                                    System.out.print("liste"+liste);
                                    suppresionObstacle = true;


                                    if (suppresionObstacle == true) {
                                        obstacle = null;
                                        System.out.println("Ceci est un obstacle " + obstacle);
                                    }
                                }
                            } else if (item != null) {
                                System.out.println("Items coords " + item.getPosX() + " " + item.getPosY());
                                System.out.println("Caract mvt : "+caracMvt[i]);
                                if (tondeuse.getPosX() == item.getPosY() && tondeuse.getPosY() == item.getPosX()) {
                                    System.out.println("les items pas les obstacle");
                                    ajouter();
                                    ajouter();
                                    System.out.print(liste);
                                    suppresionItem = true;
                                    //item = null;

                                    if (suppresionItem == true) {
                                        item = null;
                                        System.out.println("Ceci est un item " + item);
                                    }
                                }
                            } else {
                                System.out.println("item = " + item);
                                System.out.println("obstacle = " + obstacle);
                            }
                        }

                    }
                } catch (ArrayIndexOutOfBoundsException e) {
                    System.out.println("Les coordonnées du collider entrent en conflit avec la taille de la grille");
                }

            }
        } catch (NullPointerException e) {
            System.out.println("Une NullPointerException est survenue ! ");
        }
    }

    public String getCase(int c, int l) {
        System.out.println("Items coords " + item.getPosX() + " " + item.getPosY());
        return map[l][c];
    }

    public void afficher() {

        for (int i = 1; i < nbLig; i++) {

            for (int j = 1; j < nbCol; j++) {

                System.out.print("|" + map[i][j]);
            }

            System.out.println("|");
        }
        System.out.println("------------------------TABLEAU SUIVANT---------------------------------");

    }

    public void spawnCollider(String collider) {
        if (collider.equals("O")) {
            obstacle = new Obstacle();
        } else if (collider.equals("I")) {
            item = new Items();
            System.out.println("HELLO JE SUIS UN ITEM");
            //placer(item.getPosY(), item.getPosX(), "I");
        } else if (collider.equals("T")) {
            tondeuse = new Tondeuse();
            //placer(tondeuse.getPosY(),tondeuse.getPosX(), "y");
        }
    }

    public void placer(int l, int c, String t) {

        if (l < 1 || c < 1 || l > nbLig || c > nbCol) {

            System.out.print("Erreur de placement.\n");

        }

        if (map[l][c].equals(" ")) {

            map[l][c] = t;

        } else {
            System.out.print("Erreur, cet emplacement n'est pas vide.\n");

        }

    }

    public static String getLigne() {
        return ligne;
    }

    public static String getColonne() {
        return colonne;
    }
}
