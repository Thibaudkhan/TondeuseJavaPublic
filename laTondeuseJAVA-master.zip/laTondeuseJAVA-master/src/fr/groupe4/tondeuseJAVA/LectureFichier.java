package fr.groupe4.tondeuseJAVA;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class LectureFichier {

    public LectureFichier() {
        LireFichier();
    }

    private ArrayList<String> liste = new ArrayList<>();

    public void LireFichier() {
        System.out.println("Entrez le chemin de votre fichier de configuration.");
        Scanner sc = new Scanner(System.in);
        String filePath = sc.nextLine();

        String thisLine = "";
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(filePath));
            while ((thisLine = br.readLine()) != null) {
                String[] splited = thisLine.split(" ");
                for (int i = 0; i < splited.length; i++) {

                    liste.add(splited[i]);
                }
            }
            System.out.println("Configuration chargée");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            System.out.println("Erreur lors du chargement de la configuration");
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public String getListe(String nb) {
        return liste.get(Integer.parseInt(nb));
    }

    public int getListeLength() {
        return liste.size();
    }

}